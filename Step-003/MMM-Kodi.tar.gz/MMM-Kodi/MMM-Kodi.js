/* global Module */

/* Magic Mirror
 * Module: MM Hide All
 *
 * By EoF https://forum.magicmirror.builders/user/eof
 * MIT Licensed.
 */
var KodiGo = "stop";

Module.register("MMM-Kodi",{

	getScripts: function() {
		return ["modules/MMM-Kodi/js/jquery.js"];
	},

	getStyles: function() {
		return ["MMM-Kodi-style.css"];
	},
	
	getDom: function() {
		
		var wrapper = document.createElement("div");
		var button = document.createElement("div");
		var text = document.createElement("span");
		var overlay = document.createElement("div");
		
		button.className = "mmm-kodi";
		button.appendChild(text);
		text.innerHTML = "Media";
		
		wrapper.appendChild(button);
		
		$(button).on("click", function(){
			KodiGo = "start";
		});
		
		return wrapper;
	},

         notificationReceived: function(notification, payload, sender) {
		switch (KodiGo) {
  			case "start":
				KodiGo = "stop";
                                this.sendSocketNotification("Go");
			break;
		}
        },



});
