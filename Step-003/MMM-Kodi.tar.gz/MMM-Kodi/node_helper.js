const { spawn } = require("child_process");
var NodeHelper = require("node_helper")

module.exports = NodeHelper.create({
  socketNotificationReceived: function(notification, payload) {
    switch(notification) {
      case "Go":
        this.job()
        break
    }
  },

  job: function() {
	const sp = spawn  ("kodi-standalone");

  }
})



